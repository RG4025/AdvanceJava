package com.org;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/GradeCalculatr")
public class GradeCalculatr extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
    public GradeCalculatr() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		
		String name = request.getParameter("name");
		
		int sub1 = Integer.parseInt(request.getParameter("sub1"));
		int sub2 = Integer.parseInt(request.getParameter("sub2"));
		int sub3 = Integer.parseInt(request.getParameter("sub3"));
		
		int ave = (sub1 + sub2 + sub3) /3;
		
		if(ave >= 90 && ave <= 100) {
			
			out.printf("Congrates champ you got a A+ Grade!, With average marks %s", ave);
			
		}else if(ave >= 80 && ave <= 90) {
			out.printf("Congrates champ you got a A Grade!, With average marks %s", ave);
		}else if(ave >= 60 && ave <= 80) {
			out.printf("Congrates champ you got a B+ Grade!, With average marks %s", ave);
		}else if(ave >= 40 && ave <= 60) {
			out.printf("Congrates champ you got a B Grade!, With average marks %s", ave);
		}else if(ave >= 35 && ave <= 40) {
			out.printf("Congrates champ you passed the exam , With average marks %s", ave);
		}else {
			out.println("Opps! Soory you failed!.");
		}
		
	}

}
