package com.org;

public class FirstClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
